a, b = input(), input()
print(sorted(a) == sorted(b))