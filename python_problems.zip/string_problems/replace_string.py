s = input()
old, new = input(), input()
print(s.replace(old, new))