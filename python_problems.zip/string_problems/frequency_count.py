s = input()
for ch in set(s):
    print(ch, s.count(ch))