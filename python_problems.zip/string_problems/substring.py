s = input()
sub = input()
print(sub in s)