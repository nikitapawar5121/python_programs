arr=sorted(list(map(int,input().split())))
key=int(input())
l,r=0,len(arr)-1
found=False
while l<=r:
    m=(l+r)//2
    if arr[m]==key:
        found=True;break
    elif arr[m]<key:
        l=m+1
    else:
        r=m-1
print(found)