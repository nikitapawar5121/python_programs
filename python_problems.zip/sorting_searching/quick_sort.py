def quicksort(arr):
    if len(arr)<=1: return arr
    p=arr[len(arr)//2]
    left=[x for x in arr if x<p]
    mid=[x for x in arr if x==p]
    right=[x for x in arr if x>p]
    return quicksort(left)+mid+quicksort(right)
arr=list(map(int,input().split()))
print(quicksort(arr))