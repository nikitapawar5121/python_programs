arr = list(map(int, input().split()))
key = int(input())
print(key in arr)