arr = list(map(int, input().split()))
k = int(input())
rot = arr[k:] + arr[:k]
print(rot)