arr = list(map(int, input().split()))
print([x for x in set(arr) if arr.count(x) > 1])