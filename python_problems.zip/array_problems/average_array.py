arr = list(map(int, input().split()))
print(sum(arr)/len(arr))