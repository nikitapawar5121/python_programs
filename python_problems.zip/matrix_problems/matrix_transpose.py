a=[[1,2],[3,4]]
res=[[a[j][i] for j in range(len(a))] for i in range(len(a[0]))]
print(res)