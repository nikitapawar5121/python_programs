a=[[1,0],[0,1]]
print(all(a[i][j]==(1 if i==j else 0) for i in range(len(a)) for j in range(len(a))))