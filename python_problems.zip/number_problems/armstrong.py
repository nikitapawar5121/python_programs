n = int(input())
s = sum(int(d)**len(str(n)) for d in str(n))
print(s == n)